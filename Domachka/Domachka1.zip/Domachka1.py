# Домашнее задание №1

a = 11
b = 23
print("a:", a)
print("b:", b)

a = a + b
b = a - b
a = a - b

print("a:", a)
print("b:", b)